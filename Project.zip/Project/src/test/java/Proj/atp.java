package Proj;


import org.openqa.selenium.By;
import org.testng.annotations.Test;

import found.NewTest;

public class atp extends NewTest {
	  @Test
			public void ve() {
				  driver.get("https://demo.guru99.com/telecom/index.html");
				  driver.findElement(By.xpath("//*[@id=\"one\"]/div/div[1]/div[2]/h3/a")).click();
				  
				  driver.findElement(By.id("customer_id")).sendKeys("836173");
			      driver.findElement(By.name("submit")).click();
			    
			      driver.findElement(By.name("submit")).click();
			      driver.findElement(By.xpath("//*[@id=\"main\"]/div/ul/li/a")).click();
  }
}

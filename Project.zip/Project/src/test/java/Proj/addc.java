package Proj;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import found.NewTest;

public class addc extends NewTest {
  @Test(priority=1)
		public void v() {
			  driver.get("https://demo.guru99.com/telecom/index.html");
			  
			  driver.findElement(By.xpath("//*[@id=\"one\"]/div/div[1]/div[1]/h3/a\n")).click();
		      driver.findElement(By.xpath("//*[@id=\"main\"]/div/form/div/div[1]/label")).click();
		      driver.findElement(By.id("fname")).sendKeys("Rohan");
		      driver.findElement(By.id("lname")).sendKeys("H");
		      driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("rohan12@gmail.com");
		      driver.findElement(By.name("addr")).sendKeys("Bangalore  India");
		      driver.findElement(By.xpath("//*[@id=\"telephoneno\"]")).sendKeys("7894561233");
		      driver.findElement(By.name("submit")).click();
		      driver.findElement(By.xpath("//*[@id=\"main\"]/div/div/ul/li/a")).click();
		      driver.findElement(By.xpath("//*[@id=\"one\"]/div/div[1]/div[1]/h3/a\n")).click();
		      driver.findElement(By.xpath("//*[@id=\"main\"]/div/form/div/div[2]/label")).click();
		      driver.findElement(By.id("fname")).sendKeys("Ro1");
		      driver.findElement(By.id("lname")).sendKeys("H22");
		      driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("rohan12@il.com");
		      driver.findElement(By.name("addr")).sendKeys(" ");
		      driver.findElement(By.xpath("//*[@id=\"telephoneno\"]")).sendKeys("789aaaa3");
		      driver.findElement(By.name("submit")).click();
		      driver.findElement(By.xpath("//*[@id=\"main\"]/div/div/ul/li/a")).click();
	}
  
}
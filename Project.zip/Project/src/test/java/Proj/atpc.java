package Proj;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import found.NewTest;

public class atpc extends NewTest {
	  @Test
			public void veri() {
				  driver.get("https://demo.guru99.com/telecom/index.html");
				  driver.findElement(By.xpath("//*[@id=\"one\"]/div/div[3]/div[1]/h3/a")).click(); 
				  driver.findElement(By.name("rental")).sendKeys("300");
				  driver.findElement(By.name("local_minutes")).sendKeys("900");
				  driver.findElement(By.name("inter_minutes")).sendKeys("100");
				  driver.findElement(By.name("sms_pack")).sendKeys("30");
				  driver.findElement(By.name("minutes_charges")).sendKeys("2");
				  driver.findElement(By.name("inter_charges")).sendKeys("9");
				  driver.findElement(By.name("sms_charges")).sendKeys("3");
				  driver.findElement(By.name("submit")).click();
				  driver.findElement(By.xpath("//*[@id=\"main\"]/div/ul/li/a")).click();
				  
				  driver.findElement(By.xpath("//*[@id=\"one\"]/div/div[3]/div[1]/h3/a")).click(); 
				  driver.findElement(By.name("rental")).sendKeys("30055555555555");
				  driver.findElement(By.name("local_minutes")).sendKeys("90a0");
				  driver.findElement(By.name("inter_minutes")).sendKeys("10*0");
				  driver.findElement(By.name("sms_pack")).sendKeys("3pop0");
				  driver.findElement(By.name("minutes_charges")).sendKeys("  ");
				  driver.findElement(By.name("inter_charges")).sendKeys("%^&");
				  driver.findElement(By.name("sms_charges")).sendKeys(")(&^");
				  driver.findElement(By.name("submit")).click();
				  driver.findElement(By.xpath("//*[@id=\"main\"]/div/ul/li/a")).click();
	  }		  
}
 
package Proj;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import found.NewTest;

public class pb extends NewTest {
	  @Test
			public void verify() {
				  driver.get("https://demo.guru99.com/telecom/index.html");
				  driver.findElement(By.xpath("//*[@id=\"one\"]/div/div[3]/div[2]/h3/a")).click(); 
				  driver.findElement(By.id("customer_id")).sendKeys("836173");
			      driver.findElement(By.name("submit")).click();
			      driver.findElement(By.xpath("//*[@id=\"navbar-brand-centered\"]/ul/li[8]/a")).click(); 
			      driver.findElement(By.xpath("//*[@id=\"one\"]/div/div[3]/div[2]/h3/a")).click();
			      driver.findElement(By.id("customer_id")).sendKeys("abcdsee");
			      driver.findElement(By.name("submit")).click();
			      Alert alert = driver.switchTo().alert();
			      System.out.println("Alert Message: " + alert.getText());
			      alert.accept();
			      driver.findElement(By.xpath("//*[@id=\"navbar-brand-centered\"]/ul/li[8]/a")).click();
	  }
}

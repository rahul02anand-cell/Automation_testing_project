package found;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;

public class NewTest {
	protected WebDriver driver;
	protected Actions actions;
  @Test
  public void f() {
  }
  @BeforeMethod
  public void setup() {
	  driver =new ChromeDriver();
	  driver.manage().window().maximize();
	  actions=new Actions(driver);
  }

  @AfterMethod
  public void tearDown() {
	  if(driver!=null)
	  {
		 // driver.quit();
	  }
  }

}
